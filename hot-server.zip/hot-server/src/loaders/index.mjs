// import express from "express";
// import dotenv from "dotenv";
// dotenv.config();
// import hotserver from "./db/index.ts"
// import methodOverride from 'method-override';

//can do without 